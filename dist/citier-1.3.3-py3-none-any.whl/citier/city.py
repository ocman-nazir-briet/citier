def city(country, state, city):
    if country:
        pass
    elif state:
        pass
    elif city:
        pass
    return ''