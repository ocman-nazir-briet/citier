# setup.py
from setuptools import setup

setup(
    name='citier',
    version='1.3.5',
    packages=['citier'],
    install_requires=[],
)
