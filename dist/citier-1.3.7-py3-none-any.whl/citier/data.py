data = {
  "pakistan": {
    "punjab": {
      "lahore": "lahore",
      "islamabad": "islamabad",
      "multan": "multan"
    },
    "sindh": {
      "lahdore": "lahdore",
      "isldamabad": "isldamabad",
      "mdultan": "mdultan"
    }
  },
  "india": {
    "punjab": {
      "lore": "lore",
      "islabad": "islabad",
      "mltan": "mltan"
    }
  }
}