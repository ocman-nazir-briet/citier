def city(country, state, city):
    if country:
        pass
    elif state:
        pass
    elif city:
        pass
    return ''

def state(country, state, city):
    if country:
        pass
    elif state:
        pass
    elif city:
        pass
    return ''

def country(country, state, city):
    if country:
        pass
    elif state:
        pass
    elif city:
        pass
    return ''

data = {
  "pakistan": {
    "punjab": {
      "lahore": "lahore",
      "islamabad": "islamabad",
      "multan": "multan"
    },
    "sindh": {
      "lahdore": "lahdore",
      "isldamabad": "isldamabad",
      "mdultan": "mdultan"
    }
  },
  "india": {
    "punjab": {
      "lore": "lore",
      "islabad": "islabad",
      "mltan": "mltan"
    }
  }
}